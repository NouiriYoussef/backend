package com.example.Rappel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RappelApplicationTests {

	@Test
	void contextLoads() {
	}

}
